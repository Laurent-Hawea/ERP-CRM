import './styleCompiler/ww-style-page-c8516bde-2dad-4d43-88f7-0b9d0963cb99.css';
/*__WW_PAGE_COMPONENT_IMPORTS_START__*/

// eslint-disable-next-line no-undef
import element_0dc461bb_103e_4b2e_80e0_846ec3c30a6e from "@weweb-internal/ext-element-0dc461bb-103e-4b2e-80e0-846ec3c30a6e";
import element_1b1e2173_9b78_42cc_a8ee_a6167caea340 from "@weweb-internal/ext-element-1b1e2173-9b78-42cc-a8ee-a6167caea340";
import element_21881619_a984_4847_81a9_922c3dbb5853 from "@weweb-internal/ext-element-21881619-a984-4847-81a9-922c3dbb5853";
import element_3a7d6379_12d3_4387_98ff_b332bb492a63 from "@weweb-internal/ext-element-3a7d6379-12d3-4387-98ff-b332bb492a63";
import element_59dca300_db78_42e4_a7a6_0cbf22d3cc82 from "@weweb-internal/ext-element-59dca300-db78-42e4-a7a6-0cbf22d3cc82";
import element_60676ae5_99b1_4278_9330_4299cd99c5cf from "@weweb-internal/ext-element-60676ae5-99b1-4278-9330-4299cd99c5cf";
import element_6f8796b1_8273_498d_95fc_7013b7c63214 from "@weweb-internal/ext-element-6f8796b1-8273-498d-95fc-7013b7c63214";
import element_83d890fb_84f9_4386_b459_fb4be89a8e15 from "@weweb-internal/ext-element-83d890fb-84f9-4386-b459-fb4be89a8e15";
import element_85044fa4_8fc0_4115_9eaf_ca30a1b4b528 from "@weweb-internal/ext-element-85044fa4-8fc0-4115-9eaf-ca30a1b4b528";
import element_9256b033_f4e8_4ab4_adce_dac3a940d7f5 from "@weweb-internal/ext-element-9256b033-f4e8-4ab4-adce-dac3a940d7f5";
import element_97a63460_5c25_4d74_ac1f_86693c2e4a08 from "@weweb-internal/ext-element-97a63460-5c25-4d74-ac1f-86693c2e4a08";
import element_9ecb2cfc_cef7_4be8_b736_3e17a3b7e9ff from "@weweb-internal/ext-element-9ecb2cfc-cef7-4be8-b736-3e17a3b7e9ff";
import element_aa29a661_07ce_484e_8abb_456186211282 from "@weweb-internal/ext-element-aa29a661-07ce-484e-8abb-456186211282";
import element_b783dc65_d528_4f74_8c14_e27c934c39b1 from "@weweb-internal/ext-element-b783dc65-d528-4f74-8c14-e27c934c39b1";
import element_d7904e9d_fc9a_4d80_9e32_728e097879ad from "@weweb-internal/ext-element-d7904e9d-fc9a-4d80-9e32-728e097879ad";
import element_deb10a01_5eef_4aa1_9017_1b51c2ad6fd0 from "@weweb-internal/ext-element-deb10a01-5eef-4aa1-9017-1b51c2ad6fd0";

// eslint-disable-next-line no-undef
import section_99586bd3_2b15_4d6b_a025_6a50d07ca845 from "@weweb-internal/ext-section-99586bd3-2b15-4d6b-a025-6a50d07ca845";

/*__WW_PAGE_COMPONENT_IMPORTS_END__*/

import { registerSsrPageComponents } from '@/_front/rendering/ssrPageComponents';

let isRegistered = false;

export default async function registerPageComponents(app) {
    if (isRegistered) return;

    if (import.meta.env.SSR) {
        await registerSsrPageComponents(
            app,
            // eslint-disable-next-line no-undef
            /*__WW_SSR_PAGE_COMPONENT_DESCRIPTORS_START__*/
[
    {
        "baseId": "0dc461bb-103e-4b2e-80e0-846ec3c30a6e",
        "importPath": "@weweb-internal/ext-element-0dc461bb-103e-4b2e-80e0-846ec3c30a6e",
        "name": "wwobject-0dc461bb-103e-4b2e-80e0-846ec3c30a6e",
        "type": "element"
    },
    {
        "baseId": "1b1e2173-9b78-42cc-a8ee-a6167caea340",
        "importPath": "@weweb-internal/ext-element-1b1e2173-9b78-42cc-a8ee-a6167caea340",
        "name": "wwobject-1b1e2173-9b78-42cc-a8ee-a6167caea340",
        "type": "element"
    },
    {
        "baseId": "21881619-a984-4847-81a9-922c3dbb5853",
        "importPath": "@weweb-internal/ext-element-21881619-a984-4847-81a9-922c3dbb5853",
        "name": "wwobject-21881619-a984-4847-81a9-922c3dbb5853",
        "type": "element"
    },
    {
        "baseId": "3a7d6379-12d3-4387-98ff-b332bb492a63",
        "importPath": "@weweb-internal/ext-element-3a7d6379-12d3-4387-98ff-b332bb492a63",
        "name": "wwobject-3a7d6379-12d3-4387-98ff-b332bb492a63",
        "type": "element"
    },
    {
        "baseId": "59dca300-db78-42e4-a7a6-0cbf22d3cc82",
        "importPath": "@weweb-internal/ext-element-59dca300-db78-42e4-a7a6-0cbf22d3cc82",
        "name": "wwobject-59dca300-db78-42e4-a7a6-0cbf22d3cc82",
        "type": "element"
    },
    {
        "baseId": "60676ae5-99b1-4278-9330-4299cd99c5cf",
        "importPath": "@weweb-internal/ext-element-60676ae5-99b1-4278-9330-4299cd99c5cf",
        "name": "wwobject-60676ae5-99b1-4278-9330-4299cd99c5cf",
        "type": "element"
    },
    {
        "baseId": "6f8796b1-8273-498d-95fc-7013b7c63214",
        "importPath": "@weweb-internal/ext-element-6f8796b1-8273-498d-95fc-7013b7c63214",
        "name": "wwobject-6f8796b1-8273-498d-95fc-7013b7c63214",
        "type": "element"
    },
    {
        "baseId": "83d890fb-84f9-4386-b459-fb4be89a8e15",
        "importPath": "@weweb-internal/ext-element-83d890fb-84f9-4386-b459-fb4be89a8e15",
        "name": "wwobject-83d890fb-84f9-4386-b459-fb4be89a8e15",
        "type": "element"
    },
    {
        "baseId": "85044fa4-8fc0-4115-9eaf-ca30a1b4b528",
        "importPath": "@weweb-internal/ext-element-85044fa4-8fc0-4115-9eaf-ca30a1b4b528",
        "name": "wwobject-85044fa4-8fc0-4115-9eaf-ca30a1b4b528",
        "type": "element"
    },
    {
        "baseId": "9256b033-f4e8-4ab4-adce-dac3a940d7f5",
        "importPath": "@weweb-internal/ext-element-9256b033-f4e8-4ab4-adce-dac3a940d7f5",
        "name": "wwobject-9256b033-f4e8-4ab4-adce-dac3a940d7f5",
        "type": "element"
    },
    {
        "baseId": "97a63460-5c25-4d74-ac1f-86693c2e4a08",
        "importPath": "@weweb-internal/ext-element-97a63460-5c25-4d74-ac1f-86693c2e4a08",
        "name": "wwobject-97a63460-5c25-4d74-ac1f-86693c2e4a08",
        "type": "element"
    },
    {
        "baseId": "9ecb2cfc-cef7-4be8-b736-3e17a3b7e9ff",
        "importPath": "@weweb-internal/ext-element-9ecb2cfc-cef7-4be8-b736-3e17a3b7e9ff",
        "name": "wwobject-9ecb2cfc-cef7-4be8-b736-3e17a3b7e9ff",
        "type": "element"
    },
    {
        "baseId": "aa29a661-07ce-484e-8abb-456186211282",
        "importPath": "@weweb-internal/ext-element-aa29a661-07ce-484e-8abb-456186211282",
        "name": "wwobject-aa29a661-07ce-484e-8abb-456186211282",
        "type": "element"
    },
    {
        "baseId": "b783dc65-d528-4f74-8c14-e27c934c39b1",
        "importPath": "@weweb-internal/ext-element-b783dc65-d528-4f74-8c14-e27c934c39b1",
        "name": "wwobject-b783dc65-d528-4f74-8c14-e27c934c39b1",
        "type": "element"
    },
    {
        "baseId": "d7904e9d-fc9a-4d80-9e32-728e097879ad",
        "importPath": "@weweb-internal/ext-element-d7904e9d-fc9a-4d80-9e32-728e097879ad",
        "name": "wwobject-d7904e9d-fc9a-4d80-9e32-728e097879ad",
        "type": "element"
    },
    {
        "baseId": "deb10a01-5eef-4aa1-9017-1b51c2ad6fd0",
        "importPath": "@weweb-internal/ext-element-deb10a01-5eef-4aa1-9017-1b51c2ad6fd0",
        "name": "wwobject-deb10a01-5eef-4aa1-9017-1b51c2ad6fd0",
        "type": "element"
    },
    {
        "baseId": "99586bd3-2b15-4d6b-a025-6a50d07ca845",
        "importPath": "@weweb-internal/ext-section-99586bd3-2b15-4d6b-a025-6a50d07ca845",
        "name": "section-99586bd3-2b15-4d6b-a025-6a50d07ca845",
        "type": "section"
    }
]
/*__WW_SSR_PAGE_COMPONENT_DESCRIPTORS_END__*/
        );
    } else {
        // eslint-disable-next-line no-undef
        app.component("wwobject-0dc461bb-103e-4b2e-80e0-846ec3c30a6e", element_0dc461bb_103e_4b2e_80e0_846ec3c30a6e);
app.component("wwobject-1b1e2173-9b78-42cc-a8ee-a6167caea340", element_1b1e2173_9b78_42cc_a8ee_a6167caea340);
app.component("wwobject-21881619-a984-4847-81a9-922c3dbb5853", element_21881619_a984_4847_81a9_922c3dbb5853);
app.component("wwobject-3a7d6379-12d3-4387-98ff-b332bb492a63", element_3a7d6379_12d3_4387_98ff_b332bb492a63);
app.component("wwobject-59dca300-db78-42e4-a7a6-0cbf22d3cc82", element_59dca300_db78_42e4_a7a6_0cbf22d3cc82);
app.component("wwobject-60676ae5-99b1-4278-9330-4299cd99c5cf", element_60676ae5_99b1_4278_9330_4299cd99c5cf);
app.component("wwobject-6f8796b1-8273-498d-95fc-7013b7c63214", element_6f8796b1_8273_498d_95fc_7013b7c63214);
app.component("wwobject-83d890fb-84f9-4386-b459-fb4be89a8e15", element_83d890fb_84f9_4386_b459_fb4be89a8e15);
app.component("wwobject-85044fa4-8fc0-4115-9eaf-ca30a1b4b528", element_85044fa4_8fc0_4115_9eaf_ca30a1b4b528);
app.component("wwobject-9256b033-f4e8-4ab4-adce-dac3a940d7f5", element_9256b033_f4e8_4ab4_adce_dac3a940d7f5);
app.component("wwobject-97a63460-5c25-4d74-ac1f-86693c2e4a08", element_97a63460_5c25_4d74_ac1f_86693c2e4a08);
app.component("wwobject-9ecb2cfc-cef7-4be8-b736-3e17a3b7e9ff", element_9ecb2cfc_cef7_4be8_b736_3e17a3b7e9ff);
app.component("wwobject-aa29a661-07ce-484e-8abb-456186211282", element_aa29a661_07ce_484e_8abb_456186211282);
app.component("wwobject-b783dc65-d528-4f74-8c14-e27c934c39b1", element_b783dc65_d528_4f74_8c14_e27c934c39b1);
app.component("wwobject-d7904e9d-fc9a-4d80-9e32-728e097879ad", element_d7904e9d_fc9a_4d80_9e32_728e097879ad);
app.component("wwobject-deb10a01-5eef-4aa1-9017-1b51c2ad6fd0", element_deb10a01_5eef_4aa1_9017_1b51c2ad6fd0);

        // eslint-disable-next-line no-undef
        app.component("section-99586bd3-2b15-4d6b-a025-6a50d07ca845", section_99586bd3_2b15_4d6b_a025_6a50d07ca845);
    }

    isRegistered = true;
}
