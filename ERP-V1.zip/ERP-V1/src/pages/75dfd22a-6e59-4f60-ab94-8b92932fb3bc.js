import './styleCompiler/ww-style-page-75dfd22a-6e59-4f60-ab94-8b92932fb3bc.css';
/*__WW_PAGE_COMPONENT_IMPORTS_START__*/

// eslint-disable-next-line no-undef
import element_1b1e2173_9b78_42cc_a8ee_a6167caea340 from "@weweb-internal/ext-element-1b1e2173-9b78-42cc-a8ee-a6167caea340";
import element_3a7d6379_12d3_4387_98ff_b332bb492a63 from "@weweb-internal/ext-element-3a7d6379-12d3-4387-98ff-b332bb492a63";
import element_53401515_b694_4c79_a88d_abeecb1de562 from "@weweb-internal/ext-element-53401515-b694-4c79-a88d-abeecb1de562";
import element_59dca300_db78_42e4_a7a6_0cbf22d3cc82 from "@weweb-internal/ext-element-59dca300-db78-42e4-a7a6-0cbf22d3cc82";
import element_5caa9f43_842b_4d48_a84d_ad5f2cd77e25 from "@weweb-internal/ext-element-5caa9f43-842b-4d48-a84d-ad5f2cd77e25";
import element_6145eb60_0af8_4e52_bcc6_dc0f6743654e from "@weweb-internal/ext-element-6145eb60-0af8-4e52-bcc6-dc0f6743654e";
import element_69d0b3ef_b265_494c_8cd1_874da4aa1834 from "@weweb-internal/ext-element-69d0b3ef-b265-494c-8cd1-874da4aa1834";
import element_6ba133b6_a444_414f_93a5_25cd237dd398 from "@weweb-internal/ext-element-6ba133b6-a444-414f-93a5-25cd237dd398";
import element_83d890fb_84f9_4386_b459_fb4be89a8e15 from "@weweb-internal/ext-element-83d890fb-84f9-4386-b459-fb4be89a8e15";
import element_a823467c_bdc7_4cec_a38c_71875c4c214a from "@weweb-internal/ext-element-a823467c-bdc7-4cec-a38c-71875c4c214a";
import element_af811adf_94d9_49dd_ab22_e2f29ae30299 from "@weweb-internal/ext-element-af811adf-94d9-49dd-ab22-e2f29ae30299";
import element_b783dc65_d528_4f74_8c14_e27c934c39b1 from "@weweb-internal/ext-element-b783dc65-d528-4f74-8c14-e27c934c39b1";
import element_c6c0c00e_49fd_4cb9_bd78_5bc09945721e from "@weweb-internal/ext-element-c6c0c00e-49fd-4cb9-bd78-5bc09945721e";
import element_d7904e9d_fc9a_4d80_9e32_728e097879ad from "@weweb-internal/ext-element-d7904e9d-fc9a-4d80-9e32-728e097879ad";
import element_deb10a01_5eef_4aa1_9017_1b51c2ad6fd0 from "@weweb-internal/ext-element-deb10a01-5eef-4aa1-9017-1b51c2ad6fd0";

// eslint-disable-next-line no-undef
import section_99586bd3_2b15_4d6b_a025_6a50d07ca845 from "@weweb-internal/ext-section-99586bd3-2b15-4d6b-a025-6a50d07ca845";
import section_ef0ecc71_9a59_4eab_94b0_b36d66d3d61d from "@weweb-internal/ext-section-ef0ecc71-9a59-4eab-94b0-b36d66d3d61d";

/*__WW_PAGE_COMPONENT_IMPORTS_END__*/

import { registerSsrPageComponents } from '@/_front/rendering/ssrPageComponents';

let isRegistered = false;

export default async function registerPageComponents(app) {
    if (isRegistered) return;

    if (import.meta.env.SSR) {
        await registerSsrPageComponents(
            app,
            // eslint-disable-next-line no-undef
            /*__WW_SSR_PAGE_COMPONENT_DESCRIPTORS_START__*/
[
    {
        "baseId": "1b1e2173-9b78-42cc-a8ee-a6167caea340",
        "importPath": "@weweb-internal/ext-element-1b1e2173-9b78-42cc-a8ee-a6167caea340",
        "name": "wwobject-1b1e2173-9b78-42cc-a8ee-a6167caea340",
        "type": "element"
    },
    {
        "baseId": "3a7d6379-12d3-4387-98ff-b332bb492a63",
        "importPath": "@weweb-internal/ext-element-3a7d6379-12d3-4387-98ff-b332bb492a63",
        "name": "wwobject-3a7d6379-12d3-4387-98ff-b332bb492a63",
        "type": "element"
    },
    {
        "baseId": "53401515-b694-4c79-a88d-abeecb1de562",
        "importPath": "@weweb-internal/ext-element-53401515-b694-4c79-a88d-abeecb1de562",
        "name": "wwobject-53401515-b694-4c79-a88d-abeecb1de562",
        "type": "element"
    },
    {
        "baseId": "59dca300-db78-42e4-a7a6-0cbf22d3cc82",
        "importPath": "@weweb-internal/ext-element-59dca300-db78-42e4-a7a6-0cbf22d3cc82",
        "name": "wwobject-59dca300-db78-42e4-a7a6-0cbf22d3cc82",
        "type": "element"
    },
    {
        "baseId": "5caa9f43-842b-4d48-a84d-ad5f2cd77e25",
        "importPath": "@weweb-internal/ext-element-5caa9f43-842b-4d48-a84d-ad5f2cd77e25",
        "name": "wwobject-5caa9f43-842b-4d48-a84d-ad5f2cd77e25",
        "type": "element"
    },
    {
        "baseId": "6145eb60-0af8-4e52-bcc6-dc0f6743654e",
        "importPath": "@weweb-internal/ext-element-6145eb60-0af8-4e52-bcc6-dc0f6743654e",
        "name": "wwobject-6145eb60-0af8-4e52-bcc6-dc0f6743654e",
        "type": "element"
    },
    {
        "baseId": "69d0b3ef-b265-494c-8cd1-874da4aa1834",
        "importPath": "@weweb-internal/ext-element-69d0b3ef-b265-494c-8cd1-874da4aa1834",
        "name": "wwobject-69d0b3ef-b265-494c-8cd1-874da4aa1834",
        "type": "element"
    },
    {
        "baseId": "6ba133b6-a444-414f-93a5-25cd237dd398",
        "importPath": "@weweb-internal/ext-element-6ba133b6-a444-414f-93a5-25cd237dd398",
        "name": "wwobject-6ba133b6-a444-414f-93a5-25cd237dd398",
        "type": "element"
    },
    {
        "baseId": "83d890fb-84f9-4386-b459-fb4be89a8e15",
        "importPath": "@weweb-internal/ext-element-83d890fb-84f9-4386-b459-fb4be89a8e15",
        "name": "wwobject-83d890fb-84f9-4386-b459-fb4be89a8e15",
        "type": "element"
    },
    {
        "baseId": "a823467c-bdc7-4cec-a38c-71875c4c214a",
        "importPath": "@weweb-internal/ext-element-a823467c-bdc7-4cec-a38c-71875c4c214a",
        "name": "wwobject-a823467c-bdc7-4cec-a38c-71875c4c214a",
        "type": "element"
    },
    {
        "baseId": "af811adf-94d9-49dd-ab22-e2f29ae30299",
        "importPath": "@weweb-internal/ext-element-af811adf-94d9-49dd-ab22-e2f29ae30299",
        "name": "wwobject-af811adf-94d9-49dd-ab22-e2f29ae30299",
        "type": "element"
    },
    {
        "baseId": "b783dc65-d528-4f74-8c14-e27c934c39b1",
        "importPath": "@weweb-internal/ext-element-b783dc65-d528-4f74-8c14-e27c934c39b1",
        "name": "wwobject-b783dc65-d528-4f74-8c14-e27c934c39b1",
        "type": "element"
    },
    {
        "baseId": "c6c0c00e-49fd-4cb9-bd78-5bc09945721e",
        "importPath": "@weweb-internal/ext-element-c6c0c00e-49fd-4cb9-bd78-5bc09945721e",
        "name": "wwobject-c6c0c00e-49fd-4cb9-bd78-5bc09945721e",
        "type": "element"
    },
    {
        "baseId": "d7904e9d-fc9a-4d80-9e32-728e097879ad",
        "importPath": "@weweb-internal/ext-element-d7904e9d-fc9a-4d80-9e32-728e097879ad",
        "name": "wwobject-d7904e9d-fc9a-4d80-9e32-728e097879ad",
        "type": "element"
    },
    {
        "baseId": "deb10a01-5eef-4aa1-9017-1b51c2ad6fd0",
        "importPath": "@weweb-internal/ext-element-deb10a01-5eef-4aa1-9017-1b51c2ad6fd0",
        "name": "wwobject-deb10a01-5eef-4aa1-9017-1b51c2ad6fd0",
        "type": "element"
    },
    {
        "baseId": "99586bd3-2b15-4d6b-a025-6a50d07ca845",
        "importPath": "@weweb-internal/ext-section-99586bd3-2b15-4d6b-a025-6a50d07ca845",
        "name": "section-99586bd3-2b15-4d6b-a025-6a50d07ca845",
        "type": "section"
    },
    {
        "baseId": "ef0ecc71-9a59-4eab-94b0-b36d66d3d61d",
        "importPath": "@weweb-internal/ext-section-ef0ecc71-9a59-4eab-94b0-b36d66d3d61d",
        "name": "section-ef0ecc71-9a59-4eab-94b0-b36d66d3d61d",
        "type": "section"
    }
]
/*__WW_SSR_PAGE_COMPONENT_DESCRIPTORS_END__*/
        );
    } else {
        // eslint-disable-next-line no-undef
        app.component("wwobject-1b1e2173-9b78-42cc-a8ee-a6167caea340", element_1b1e2173_9b78_42cc_a8ee_a6167caea340);
app.component("wwobject-3a7d6379-12d3-4387-98ff-b332bb492a63", element_3a7d6379_12d3_4387_98ff_b332bb492a63);
app.component("wwobject-53401515-b694-4c79-a88d-abeecb1de562", element_53401515_b694_4c79_a88d_abeecb1de562);
app.component("wwobject-59dca300-db78-42e4-a7a6-0cbf22d3cc82", element_59dca300_db78_42e4_a7a6_0cbf22d3cc82);
app.component("wwobject-5caa9f43-842b-4d48-a84d-ad5f2cd77e25", element_5caa9f43_842b_4d48_a84d_ad5f2cd77e25);
app.component("wwobject-6145eb60-0af8-4e52-bcc6-dc0f6743654e", element_6145eb60_0af8_4e52_bcc6_dc0f6743654e);
app.component("wwobject-69d0b3ef-b265-494c-8cd1-874da4aa1834", element_69d0b3ef_b265_494c_8cd1_874da4aa1834);
app.component("wwobject-6ba133b6-a444-414f-93a5-25cd237dd398", element_6ba133b6_a444_414f_93a5_25cd237dd398);
app.component("wwobject-83d890fb-84f9-4386-b459-fb4be89a8e15", element_83d890fb_84f9_4386_b459_fb4be89a8e15);
app.component("wwobject-a823467c-bdc7-4cec-a38c-71875c4c214a", element_a823467c_bdc7_4cec_a38c_71875c4c214a);
app.component("wwobject-af811adf-94d9-49dd-ab22-e2f29ae30299", element_af811adf_94d9_49dd_ab22_e2f29ae30299);
app.component("wwobject-b783dc65-d528-4f74-8c14-e27c934c39b1", element_b783dc65_d528_4f74_8c14_e27c934c39b1);
app.component("wwobject-c6c0c00e-49fd-4cb9-bd78-5bc09945721e", element_c6c0c00e_49fd_4cb9_bd78_5bc09945721e);
app.component("wwobject-d7904e9d-fc9a-4d80-9e32-728e097879ad", element_d7904e9d_fc9a_4d80_9e32_728e097879ad);
app.component("wwobject-deb10a01-5eef-4aa1-9017-1b51c2ad6fd0", element_deb10a01_5eef_4aa1_9017_1b51c2ad6fd0);

        // eslint-disable-next-line no-undef
        app.component("section-99586bd3-2b15-4d6b-a025-6a50d07ca845", section_99586bd3_2b15_4d6b_a025_6a50d07ca845);
app.component("section-ef0ecc71-9a59-4eab-94b0-b36d66d3d61d", section_ef0ecc71_9a59_4eab_94b0_b36d66d3d61d);
    }

    isRegistered = true;
}
